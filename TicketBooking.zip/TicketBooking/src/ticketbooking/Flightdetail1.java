package ticketbooking;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import ticketbooking.Oneway;
import static ticketbooking.Oneway.sour;
public class Flightdetail1 extends javax.swing.JFrame {
    static String x,sour,dest;
    static int fare,nop,totalfare;
    public Flightdetail1() {
        initComponents();
        
        label1.setText(Oneway.x);
        x=label1.getText();
        label2.setText(Oneway.sour);
        sour=label2.getText();
        label3.setText(Oneway.dest);
        dest=label3.getText();
        table.setVisible(false);
        table.setEnabled(false);
        nop=Oneway.nop;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        label1 = new javax.swing.JLabel();
        b1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        label3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        t1 = new javax.swing.JTextField();
        b2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 503, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 393, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setText("label1");
        jPanel2.add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 17, -1, -1));

        b1.setText("Click here");
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        jPanel2.add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, -1, -1));

        jLabel1.setText(" to show flights from");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 17, -1, -1));

        label2.setText("label2");
        jPanel2.add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 17, -1, -1));

        jLabel4.setText("to");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 17, -1, -1));

        label3.setText("label3");
        jPanel2.add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 17, -1, -1));

        jLabel2.setText("Enter Flight No. that you want to choose:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 368, -1, -1));

        t1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t1ActionPerformed(evt);
            }
        });
        jPanel2.add(t1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 365, 128, -1));

        b2.setText("Submit");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        jPanel2.add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(173, 416, -1, -1));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8"
            }
        ));
        jScrollPane1.setViewportView(table);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 830, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
String fno=t1.getText();
Random rd=new Random();
int r=rd.nextInt(100);
try{
    Connection con=null;
    Class.forName("oracle.jdbc.driver.OracleDriver");
    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","8522");
    PreparedStatement pst=con.prepareStatement("Select fare from Aeroplane where Flight_No=?");
    pst.setString(1,fno);
    ResultSet x=pst.executeQuery();
    if(x.next())
    {
        fare=x.getInt("fare");
        System.out.println(fare);
    }
totalfare=fare*nop;
    JOptionPane.showMessageDialog(this,"Your flight tickets have been booked.\nTravel ID:"+r+"\nTotal payable amount:"+totalfare);
    this.setVisible(false);
    new Thankyou().setVisible(true);
}
catch(Exception e)
{
    System.out.println(e);
}
        
    }//GEN-LAST:event_b2ActionPerformed

    private void t1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t1ActionPerformed

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed

try{
    Connection con=null;
    Class.forName("oracle.jdbc.driver.OracleDriver");
    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","8522");
    PreparedStatement pst=con.prepareStatement("Select * from Aeroplane where Source=? and Destination=?");
    pst.setString(1,sour);
    pst.setString(2,dest);
    ResultSet x=pst.executeQuery();
    
    
        table.setModel(DbUtils.resultSetToTableModel(x));
        table.setVisible(true);
    
}
catch(Exception e)
{
    System.out.println(e);
}
    }//GEN-LAST:event_b1ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new Flightdetail1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
    private javax.swing.JTextField t1;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
